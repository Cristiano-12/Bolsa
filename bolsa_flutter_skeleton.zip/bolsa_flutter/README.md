# Bolsa

Flutter Web/mobile skeleton for a scholarship discovery app.

## Prepared for

- GitHub Pages deployment.
- API-backed scholarship data.
- Multiple database providers through repository interfaces.
- Localization.
- Empty-state first UI with no fake scholarship content.

## Build for GitHub Pages

```bash
flutter build web --release --base-href /Bolsa/
```
