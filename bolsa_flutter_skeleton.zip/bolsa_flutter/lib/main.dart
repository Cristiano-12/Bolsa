import 'package:flutter/material.dart';

import 'app/bolsa_app.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const BolsaApp());
}
