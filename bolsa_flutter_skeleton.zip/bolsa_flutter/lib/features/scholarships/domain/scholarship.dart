class Scholarship {
  const Scholarship({
    required this.id,
    required this.country,
    required this.institution,
    required this.fundingLabel,
    required this.level,
    required this.imageUrl,
    required this.openDate,
    required this.postedDate,
    required this.closeDate,
    required this.fundingDetails,
    required this.location,
    required this.contact,
    required this.likes,
    required this.comments,
    required this.saves,
    required this.shares,
  });

  final String id;
  final String country;
  final String institution;
  final String fundingLabel;
  final String level;
  final String imageUrl;
  final DateTime? openDate;
  final DateTime? postedDate;
  final DateTime? closeDate;
  final String fundingDetails;
  final String location;
  final String contact;
  final int likes;
  final int comments;
  final int saves;
  final int shares;
}
