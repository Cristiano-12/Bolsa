import 'scholarship.dart';

abstract interface class ScholarshipRepository {
  Future<List<Scholarship>> search({
    String query = '',
    String? country,
    String? level,
    bool fullyFundedOnly = false,
  });

  Future<void> save(String scholarshipId);

  Future<void> unsave(String scholarshipId);
}
