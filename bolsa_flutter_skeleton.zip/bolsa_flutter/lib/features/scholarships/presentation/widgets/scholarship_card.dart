import 'package:flutter/material.dart';

import '../../../../core/theme/app_theme.dart';
import '../../domain/scholarship.dart';

class ScholarshipCard extends StatelessWidget {
  const ScholarshipCard({
    super.key,
    required this.scholarship,
  });

  final Scholarship scholarship;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(30),
        boxShadow: [
          BoxShadow(
            color: AppTheme.primaryBlue.withOpacity(.1),
            blurRadius: 30,
            offset: const Offset(0, 18),
          ),
        ],
      ),
      child: const SizedBox(height: 360),
    );
  }
}
