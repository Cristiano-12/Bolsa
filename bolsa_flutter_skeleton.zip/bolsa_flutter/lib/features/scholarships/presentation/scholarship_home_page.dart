import 'dart:ui';

import 'package:flutter/material.dart';

import '../../../core/i18n/app_localizations.dart';
import '../../../core/theme/app_theme.dart';
import '../data/scholarship_repository_placeholder.dart';
import '../domain/scholarship.dart';
import '../../../shared/widgets/frosted_icon_button.dart';
import 'widgets/empty_scholarship_card.dart';
import 'widgets/scholarship_card.dart';

class ScholarshipHomePage extends StatefulWidget {
  const ScholarshipHomePage({super.key});

  @override
  State<ScholarshipHomePage> createState() => _ScholarshipHomePageState();
}

class _ScholarshipHomePageState extends State<ScholarshipHomePage> {
  final _repository = const ScholarshipRepositoryPlaceholder();
  final _search = TextEditingController();
  var _selectedIndex = 0;
  var _items = <Scholarship>[];
  var _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final result = await _repository.search(query: _search.text.trim());
    if (!mounted) return;
    setState(() {
      _items = result;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);

    return Scaffold(
      body: Stack(
        children: [
          const _SoftBackground(),
          SafeArea(
            bottom: false,
            child: CustomScrollView(
              physics: const BouncingScrollPhysics(),
              slivers: [
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(24, 20, 24, 0),
                  sliver: SliverToBoxAdapter(
                    child: _Header(
                      title: t.text('title'),
                      searchHint: t.text('searchHint'),
                      controller: _search,
                      onSearch: _load,
                    ),
                  ),
                ),
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(16, 24, 16, 128),
                  sliver: _loading
                      ? const SliverToBoxAdapter(child: _LoadingState())
                      : _items.isEmpty
                          ? SliverToBoxAdapter(
                              child: EmptyScholarshipCard(
                                title: t.text('emptyTitle'),
                                subtitle: t.text('emptySubtitle'),
                              ),
                            )
                          : SliverList.separated(
                              itemBuilder: (context, index) {
                                return ScholarshipCard(
                                  scholarship: _items[index],
                                );
                              },
                              separatorBuilder: (_, __) =>
                                  const SizedBox(height: 20),
                              itemCount: _items.length,
                            ),
                ),
              ],
            ),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: _FloatingNavBar(
              selectedIndex: _selectedIndex,
              labels: [
                t.text('home'),
                t.text('profile'),
                t.text('banks'),
                t.text('ai'),
              ],
              onSelected: (index) {
                setState(() => _selectedIndex = index);
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _Header extends StatelessWidget {
  const _Header({
    required this.title,
    required this.searchHint,
    required this.controller,
    required this.onSearch,
  });

  final String title;
  final String searchHint;
  final TextEditingController controller;
  final VoidCallback onSearch;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          children: [
            Expanded(
              child: Text(
                title,
                style: Theme.of(context).textTheme.displayLarge,
              ),
            ),
            FrostedIconButton(
              icon: Icons.notifications_none_rounded,
              onPressed: () {},
              showDot: true,
            ),
            const SizedBox(width: 12),
            FrostedIconButton(
              icon: Icons.settings_rounded,
              onPressed: () {},
            ),
          ],
        ),
        const SizedBox(height: 22),
        ClipRRect(
          borderRadius: BorderRadius.circular(28),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
            child: TextField(
              controller: controller,
              onSubmitted: (_) => onSearch(),
              textInputAction: TextInputAction.search,
              decoration: InputDecoration(
                hintText: searchHint,
                prefixIcon: const Icon(Icons.search_rounded),
                suffixIcon: IconButton(
                  onPressed: () {},
                  icon: const Icon(Icons.tune_rounded),
                ),
                filled: true,
                fillColor: Colors.white.withOpacity(.76),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(28),
                  borderSide: BorderSide.none,
                ),
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 18,
                  vertical: 18,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _FloatingNavBar extends StatelessWidget {
  const _FloatingNavBar({
    required this.selectedIndex,
    required this.labels,
    required this.onSelected,
  });

  final int selectedIndex;
  final List<String> labels;
  final ValueChanged<int> onSelected;

  @override
  Widget build(BuildContext context) {
    final icons = [
      Icons.home_rounded,
      Icons.person_outline_rounded,
      Icons.groups_2_outlined,
      Icons.auto_awesome_rounded,
    ];

    return SafeArea(
      minimum: const EdgeInsets.fromLTRB(36, 0, 36, 18),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(34),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 22, sigmaY: 22),
          child: Container(
            height: 82,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(.78),
              borderRadius: BorderRadius.circular(34),
              border: Border.all(color: Colors.white.withOpacity(.72)),
              boxShadow: [
                BoxShadow(
                  color: AppTheme.primaryBlue.withOpacity(.12),
                  blurRadius: 28,
                  offset: const Offset(0, 14),
                ),
              ],
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: List.generate(labels.length, (index) {
                final selected = selectedIndex == index;
                return InkWell(
                  borderRadius: BorderRadius.circular(28),
                  onTap: () => onSelected(index),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 220),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 10,
                    ),
                    decoration: BoxDecoration(
                      color: selected
                          ? AppTheme.primaryBlue.withOpacity(.12)
                          : Colors.transparent,
                      borderRadius: BorderRadius.circular(28),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        CircleAvatar(
                          radius: 22,
                          backgroundColor: selected
                              ? AppTheme.primaryBlue
                              : Colors.white.withOpacity(.72),
                          child: Icon(
                            icons[index],
                            color: selected ? Colors.white : AppTheme.muted,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          labels[index],
                          style: TextStyle(
                            color:
                                selected ? AppTheme.primaryBlue : AppTheme.muted,
                            fontWeight:
                                selected ? FontWeight.w800 : FontWeight.w600,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }),
            ),
          ),
        ),
      ),
    );
  }
}

class _LoadingState extends StatelessWidget {
  const _LoadingState();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(48),
        child: CircularProgressIndicator(),
      ),
    );
  }
}

class _SoftBackground extends StatelessWidget {
  const _SoftBackground();

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            const Color(0xFFEAF6FF),
            Colors.white,
            AppTheme.softBlue.withOpacity(.7),
          ],
        ),
      ),
      child: const SizedBox.expand(),
    );
  }
}
