import '../domain/scholarship.dart';
import '../domain/scholarship_repository.dart';

class ScholarshipRepositoryPlaceholder implements ScholarshipRepository {
  const ScholarshipRepositoryPlaceholder();

  @override
  Future<List<Scholarship>> search({
    String query = '',
    String? country,
    String? level,
    bool fullyFundedOnly = false,
  }) async {
    return const [];
  }

  @override
  Future<void> save(String scholarshipId) async {}

  @override
  Future<void> unsave(String scholarshipId) async {}
}
