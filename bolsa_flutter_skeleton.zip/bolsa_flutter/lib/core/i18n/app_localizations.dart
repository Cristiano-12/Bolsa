import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

class AppLocalizations {
  const AppLocalizations(this.locale);

  final Locale locale;

  static const supportedLocales = [
    Locale('pt'),
    Locale('en'),
    Locale('fr'),
  ];

  static const delegates = [
    _AppLocalizationsDelegate(),
    GlobalMaterialLocalizations.delegate,
    GlobalWidgetsLocalizations.delegate,
    GlobalCupertinoLocalizations.delegate,
  ];

  static AppLocalizations of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations)!;
  }

  static const _values = {
    'pt': {
      'title': 'Scholarship',
      'searchHint': 'Buscar bolsas, universidades...',
      'emptyTitle': 'Nenhuma bolsa carregada',
      'emptySubtitle': 'Conecta uma API ou base de dados para apresentar oportunidades reais.',
      'home': 'Home',
      'profile': 'Perfil',
      'banks': 'Bancas',
      'ai': 'IA',
    },
    'en': {
      'title': 'Scholarship',
      'searchHint': 'Search scholarships, universities...',
      'emptyTitle': 'No scholarships loaded',
      'emptySubtitle': 'Connect an API or database to display real opportunities.',
      'home': 'Home',
      'profile': 'Profile',
      'banks': 'Boards',
      'ai': 'AI',
    },
    'fr': {
      'title': 'Scholarship',
      'searchHint': 'Rechercher des bourses, universités...',
      'emptyTitle': 'Aucune bourse chargée',
      'emptySubtitle': 'Connectez une API ou une base de données pour afficher des opportunités réelles.',
      'home': 'Accueil',
      'profile': 'Profil',
      'banks': 'Bourses',
      'ai': 'IA',
    },
  };

  String text(String key) {
    return _values[locale.languageCode]?[key] ?? _values['pt']![key] ?? key;
  }
}

class _AppLocalizationsDelegate extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) {
    return AppLocalizations.supportedLocales
        .map((supported) => supported.languageCode)
        .contains(locale.languageCode);
  }

  @override
  Future<AppLocalizations> load(Locale locale) async {
    return AppLocalizations(locale);
  }

  @override
  bool shouldReload(covariant LocalizationsDelegate<AppLocalizations> old) {
    return false;
  }
}
