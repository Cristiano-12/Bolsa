abstract interface class NotificationService {
  Future<void> initialize();

  Future<void> requestPermission();

  Future<void> subscribeToScholarshipAlerts({
    String? country,
    String? level,
    bool fullyFundedOnly = false,
  });
}

class UnconfiguredNotificationService implements NotificationService {
  const UnconfiguredNotificationService();

  @override
  Future<void> initialize() async {}

  @override
  Future<void> requestPermission() async {}

  @override
  Future<void> subscribeToScholarshipAlerts({
    String? country,
    String? level,
    bool fullyFundedOnly = false,
  }) async {}
}
