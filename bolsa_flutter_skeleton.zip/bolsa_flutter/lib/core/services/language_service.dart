import 'package:flutter/material.dart';

abstract interface class LanguageService {
  Locale get currentLocale;

  Future<void> setLocale(Locale locale);
}

class DeviceLanguageService implements LanguageService {
  DeviceLanguageService([Locale? initialLocale])
      : _currentLocale = initialLocale ?? const Locale('pt');

  Locale _currentLocale;

  @override
  Locale get currentLocale => _currentLocale;

  @override
  Future<void> setLocale(Locale locale) async {
    _currentLocale = locale;
  }
}
