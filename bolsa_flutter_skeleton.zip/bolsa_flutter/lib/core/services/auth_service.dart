abstract interface class AuthService {
  Future<bool> get isSignedIn;

  Future<void> signIn();

  Future<void> signOut();
}

class GuestAuthService implements AuthService {
  const GuestAuthService();

  @override
  Future<bool> get isSignedIn async => false;

  @override
  Future<void> signIn() async {}

  @override
  Future<void> signOut() async {}
}
