import 'package:flutter/material.dart';

class AppTheme {
  static const navy = Color(0xFF071B52);
  static const primaryBlue = Color(0xFF005BEA);
  static const softBlue = Color(0xFFEAF5FF);
  static const page = Color(0xFFF3F9FF);
  static const muted = Color(0xFF6B7891);

  static ThemeData get light {
    return ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: page,
      colorScheme: ColorScheme.fromSeed(
        seedColor: primaryBlue,
        brightness: Brightness.light,
        primary: primaryBlue,
      ),
      textTheme: const TextTheme(
        displayLarge: TextStyle(
          color: navy,
          fontSize: 42,
          fontWeight: FontWeight.w800,
          letterSpacing: 0,
        ),
        titleLarge: TextStyle(
          color: navy,
          fontSize: 20,
          fontWeight: FontWeight.w800,
        ),
        bodyMedium: TextStyle(
          color: muted,
          fontSize: 14,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }
}
