abstract interface class DatabaseClient {
  Future<List<Map<String, dynamic>>> readCollection(
    String collection, {
    Map<String, Object?> filters = const {},
  });

  Future<void> writeDocument(
    String collection,
    String id,
    Map<String, dynamic> data,
  );
}

class UnconfiguredDatabaseClient implements DatabaseClient {
  const UnconfiguredDatabaseClient();

  @override
  Future<List<Map<String, dynamic>>> readCollection(
    String collection, {
    Map<String, Object?> filters = const {},
  }) {
    throw StateError('Database client is not configured yet.');
  }

  @override
  Future<void> writeDocument(
    String collection,
    String id,
    Map<String, dynamic> data,
  }) {
    throw StateError('Database client is not configured yet.');
  }
}
