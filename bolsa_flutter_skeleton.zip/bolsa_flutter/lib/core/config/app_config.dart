class AppConfig {
  const AppConfig({
    required this.apiBaseUrl,
    required this.databaseProvider,
  });

  final String apiBaseUrl;
  final DatabaseProvider databaseProvider;

  static const current = AppConfig(
    apiBaseUrl: String.fromEnvironment('API_BASE_URL'),
    databaseProvider: DatabaseProvider.rest,
  );
}

enum DatabaseProvider {
  rest,
  supabase,
  firebase,
  local,
}
