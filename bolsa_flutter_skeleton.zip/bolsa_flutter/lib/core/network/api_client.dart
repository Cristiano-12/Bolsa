abstract interface class ApiClient {
  Future<Map<String, dynamic>> getJson(
    String path, {
    Map<String, String>? query,
  });

  Future<Map<String, dynamic>> postJson(
    String path, {
    Map<String, dynamic>? body,
  });
}

class UnconfiguredApiClient implements ApiClient {
  const UnconfiguredApiClient();

  @override
  Future<Map<String, dynamic>> getJson(
    String path, {
    Map<String, String>? query,
  }) {
    throw StateError('API client is not configured yet.');
  }

  @override
  Future<Map<String, dynamic>> postJson(
    String path, {
    Map<String, dynamic>? body,
  }) {
    throw StateError('API client is not configured yet.');
  }
}
