import 'package:flutter/material.dart';

import '../core/i18n/app_localizations.dart';
import '../core/theme/app_theme.dart';
import '../features/scholarships/presentation/scholarship_home_page.dart';

class BolsaApp extends StatelessWidget {
  const BolsaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Bolsa',
      theme: AppTheme.light,
      supportedLocales: AppLocalizations.supportedLocales,
      localizationsDelegates: AppLocalizations.delegates,
      home: const ScholarshipHomePage(),
    );
  }
}
